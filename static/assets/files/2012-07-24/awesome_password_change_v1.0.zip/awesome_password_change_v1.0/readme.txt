Awesome Passwort Change

AUTHOR: Niklas Heer
MAIL: niklas.heer@me.com
URL: http://niklas-heer.de
VERSION: 1.0
LICENSE: This work is licensed under:
 		* Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
 		* Link: http://creativecommons.org/licenses/by-nc-sa/3.0/
		
You can use this for your own website!

If you want to remove the copyright, please contact the author via mail: niklas.heer@me.cpm!

INSTALL:

Copy all files to your webserver, open config/config.php and edit it to your needs!
Done!

Have fun! :D

-- Made with love in Germany :D
Niklas
