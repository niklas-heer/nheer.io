<?php
/**
 * Awesome Password Change
 *
 * LICENSE: This work is licensed under:
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
 * Link: http://creativecommons.org/licenses/by-nc-sa/3.0/
 *
 * @author     Niklas Heer <niklas.heer@me.com>
 * @copyright  2012 - http://niklas-heer.de
 * @license    http://creativecommons.org/licenses/by-nc-sa/3.0/  CC BY-NC-SA
 * @link       http://niklas-heer.de
 * @version	   1.0
 */
 // JQuery Valid8 is part of this script and was developed by jan.jarfalk(jan.jarfalk@unwrongest.com) see jquery.valid8.source.js for further information
 
 // DON'T CHANGE ANYTHING HERE! CONTACT THE AUTHOR (NIKLAS HEER) IF YOU WANT TO DO SO! MAIL: niklas.heer@me.com
	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo '<div class="copyright"><a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">Awesome Password Change</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://niklas-heer.de" property="cc:attributionName" rel="cc:attributionURL">Niklas Heer</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/">Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License</a>.<br />Based on a work at <a xmlns:dct="http://purl.org/dc/terms/" href="http://unwrongest.com/projects/valid8/" rel="dct:source">http://unwrongest.com/projects/valid8/</a>.</div>';

?>

